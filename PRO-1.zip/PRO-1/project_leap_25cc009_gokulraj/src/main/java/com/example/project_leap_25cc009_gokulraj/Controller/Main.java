package com.example.project_leap_25cc009_gokulraj.Controller;

public class Main {
    static void main() {
        WebController e= new WebController();
//        e.calculate(2,3,"+");
    }
}