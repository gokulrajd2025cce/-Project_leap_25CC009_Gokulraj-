package com.example.project_leap_25cc009_gokulraj.Modal;

import org.springframework.web.bind.annotation.GetMapping;

public class Student {
    private String rollNo;
    private String department;
    private String name;

    public Student(String rollNo, String department, String name) {
        this.rollNo = rollNo;
        this.department = department;
        this.name = name;
    }
    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getRollNo() {
        return rollNo;
    }

    public void setRollNo(String rollNo) {
        this.rollNo = rollNo;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
