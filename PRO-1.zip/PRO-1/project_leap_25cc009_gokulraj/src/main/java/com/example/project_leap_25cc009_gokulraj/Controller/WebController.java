package com.example.project_leap_25cc009_gokulraj.Controller;

import com.example.project_leap_25cc009_gokulraj.Modal.Student;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class WebController {
//    @PostMapping("/calculate")
//    int calculate(int a, int b, String operation) {
//        switch (operation) {
//            case "+" -> {
//                return a + b;
//            }
//            case "-" -> {
//                return a - b;
//            }
//            case "*" -> {
//                return a * b;
//            }
//            case "/" -> {
//                return a / b;
//            }
//
//        }
//        return 0;
//    }
    @GetMapping ("/student")
    public Student getStudentDetails(){
        Student student = new Student("25cc009","CCE","Gokul");
        student.setName("sujith");
        student.setDepartment("CCE");
        student.setRollNo("25CC058");
        return student;
    }
}
