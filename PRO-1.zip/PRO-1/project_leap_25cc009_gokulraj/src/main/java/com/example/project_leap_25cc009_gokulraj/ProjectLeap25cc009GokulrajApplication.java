package com.example.project_leap_25cc009_gokulraj;

 import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectLeap25cc009GokulrajApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectLeap25cc009GokulrajApplication.class, args);
	}

}
