package com.example.project_leap_25cc009_gokulraj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectLeap25cc009GokulrajApplicationTests {

	@Test
	void contextLoads() {
	}

}
