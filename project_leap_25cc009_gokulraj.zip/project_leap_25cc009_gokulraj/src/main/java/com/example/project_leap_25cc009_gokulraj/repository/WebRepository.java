package com.example.project_leap_25cc009_gokulraj.repository;

import com.example.project_leap_25cc009_gokulraj.model.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import javax.xml.crypto.Data;

@Repository
public interface WebRepository extends JpaRepository<Student,Long> {

}
