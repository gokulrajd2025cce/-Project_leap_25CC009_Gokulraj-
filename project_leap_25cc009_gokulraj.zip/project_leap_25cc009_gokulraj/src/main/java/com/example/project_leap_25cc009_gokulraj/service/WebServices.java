package com.example.project_leap_25cc009_gokulraj.service;

import com.example.project_leap_25cc009_gokulraj.model.Student;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface WebServices    {
//    String WriteDataFromController(String data);
//    String ReadDataFromController();
    Student saveStudent(Student student);
    void deleteStudent(Long id);
    List<Student> readStudents();
    Student updateStudent(Student student);
}
