package com.example.project_leap_25cc009_gokulraj.service.impl;

import com.example.project_leap_25cc009_gokulraj.model.Student;
import com.example.project_leap_25cc009_gokulraj.repository.WebRepository;
import com.example.project_leap_25cc009_gokulraj.service.WebServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.io.IOException;
import java.nio.file.Files;
import java.util.List;

@Service
public class WebServiceImpl implements WebServices {
    @Autowired


    @Override
    public Student saveStudent(Student student) {
        return null;
    }

    @Override
    public void deleteStudent(Long id) {

    }

    @Override
    public List<Student> readStudents() {
        return List.of();
    }

    @Override
    public Student updateStudent(Student student) {
        return null;
    }
}